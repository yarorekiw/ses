#include "mainwindow.h"
#include <QDebug>
#include <string>
#include <vector>

std::vector<std::string> btns_map = {
    "789/",
    "456*",
    "123-",
    "C0.+"
};

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
    //this->resize(640, 480);
    this->setWindowTitle("Calculator");
    this->_centralWidget = new QWidget(this);
    this->setCentralWidget(this->_centralWidget);
    this->layout = new QGridLayout();
    this->_centralWidget->setLayout(this->layout);
    this->buttons = new QList<QPushButton*>;

    this->display = new QLabel(QString("0"), this->_centralWidget);
    this->display->setStyleSheet("border: 1px solid black; padding: 2px;");
    this->display->setAlignment(Qt::AlignRight);
    this->display->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);

    this->layout->addWidget(this->display, 0, 0, 1, 3);

    auto btn = new QPushButton(QString("="), this->_centralWidget);
    btn->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
    QObject::connect(btn, &QPushButton::clicked, std::bind(&MainWindow::on_click, this, QString("=")));
    this->buttons->push_front(btn);
    this->layout->addWidget(btn, 0, 3);
    int row_index = 1;
    for (auto row: btns_map){
        int col_index = 0;
        for (auto cell: row){
            auto btn = new QPushButton(QString(cell), this->_centralWidget);
            btn->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
            QObject::connect(btn, &QPushButton::clicked, std::bind(&MainWindow::on_click, this, QString(cell)));
            this->buttons->push_front(btn);
            this->layout->addWidget(btn, row_index, col_index);
            col_index++;
        }
        row_index++;
    }
}

void MainWindow::on_click(QString value) {
    qInfo() << value;
    if (value.indexOf("=") >= 0) return;
    if (value.indexOf("C") >= 0) {
        this->display->setText("0");
        return;
    }
    if (this->display->text() == QString("0"))
        this->display->setText(value);
    else
        this->display->setText(this->display->text() + value);
}

MainWindow::~MainWindow() {
    for (auto button: *this->buttons)
        delete button;
    delete this->buttons;
    delete this->display;
    delete this->layout;
    delete this->_centralWidget;
}
