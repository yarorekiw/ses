#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QPushButton>
#include <QLabel>
#include <QList>
#include <QGridLayout>
#include <QWidget>
#include <QSizePolicy>
#include <QObject>

class MainWindow : public QMainWindow
{
    Q_OBJECT
    QList<QPushButton*> *buttons;
    QLabel *display;
    QWidget *_centralWidget;
    QGridLayout *layout;

private slots:
    void on_click(QString value);

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
};
#endif // MAINWINDOW_H
